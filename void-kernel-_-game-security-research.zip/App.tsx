import React, { useState, useEffect, useCallback, useRef } from 'react';
import { TUTORS } from './constants';
import { Message, Role, TutorProfile } from './types';
import { createChatSession, sendMessageToChat } from './services/geminiService';
import { Sidebar } from './components/Sidebar';
import { ChatArea } from './components/ChatArea';
import { InputArea } from './components/InputArea';
import { LandingPage } from './components/LandingPage';
import { Chat } from '@google/genai';
import { Menu, Terminal } from 'lucide-react';

export default function App() {
  const [view, setView] = useState<'landing' | 'chat'>('landing');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [chatSession, setChatSession] = useState<Chat | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  
  // Single specialized tutor
  const currentTutor = TUTORS[0]; 

  // Initialize Chat
  const startSession = async () => {
    try {
      setMessages([]);
      setIsStreaming(false);
      const newChat = createChatSession(currentTutor.model, currentTutor.systemInstruction);
      setChatSession(newChat);
      
      // Initial System Boot Message
      const greeting: Message = {
        id: 'init-boot',
        role: Role.MODEL,
        text: `**VOID KERNEL v3.1**\n\nConnection established.\nSecure channel active.\n\nReady for query.`,
        timestamp: Date.now()
      };
      setMessages([greeting]);
    } catch (error) {
      console.error("Failed to initialize chat", error);
    }
  };

  const handleEnter = () => {
    setView('chat');
    startSession();
  };

  const handleSendMessage = useCallback(async (text: string) => {
    if (!chatSession) return;

    // Create user message
    const userMsg: Message = {
      id: Date.now().toString(),
      role: Role.USER,
      text: text,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMsg]);
    setIsStreaming(true);

    // Create placeholder for AI response
    const aiMsgId = (Date.now() + 1).toString();
    const aiMsgPlaceholder: Message = {
      id: aiMsgId,
      role: Role.MODEL,
      text: '', 
      timestamp: Date.now()
    };
    setMessages(prev => [...prev, aiMsgPlaceholder]);

    try {
      const stream = await sendMessageToChat(chatSession, text);
      let fullText = '';
      for await (const chunk of stream) {
        fullText += chunk;
        setMessages(prev => prev.map(msg => 
          msg.id === aiMsgId ? { ...msg, text: fullText } : msg
        ));
      }
    } catch (error) {
      console.error("Streaming error:", error);
      setMessages(prev => prev.map(msg => 
        msg.id === aiMsgId ? { ...msg, isError: true, text: msg.text + "\n[FATAL ERROR: CONNECTION SEVERED]" } : msg
      ));
    } finally {
      setIsStreaming(false);
    }
  }, [chatSession]);

  const handleStop = useCallback(() => {
    setIsStreaming(false);
  }, []);

  if (view === 'landing') {
    return <LandingPage onEnter={handleEnter} />;
  }

  return (
    <div className="flex h-screen bg-void-900 overflow-hidden font-sans">
      
      {/* Sidebar (Status Panel) */}
      <Sidebar 
        currentTutor={currentTutor}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
      />

      {/* Main Content */}
      <div className="flex-1 flex flex-col relative w-full h-full bg-void-900 bg-noise">
        
        {/* Mobile Header */}
        <div className="md:hidden flex items-center p-4 border-b border-goth-border bg-void-900/90 backdrop-blur-md sticky top-0 z-10">
          <button 
            onClick={() => setIsSidebarOpen(true)}
            className="p-2 -ml-2 text-goth-muted hover:text-white"
          >
            <Menu size={24} />
          </button>
          <div className="ml-4 flex items-center gap-2">
            <Terminal size={16} className="text-crimson-500"/>
            <span className="font-goth font-bold text-gray-200 tracking-widest">VOID KERNEL</span>
          </div>
        </div>

        {/* Chat Area */}
        <ChatArea 
          messages={messages} 
          isStreaming={isStreaming} 
          currentTutorName={currentTutor.name}
        />

        {/* Input Area */}
        <InputArea 
          onSend={handleSendMessage}
          onStop={handleStop}
          isStreaming={isStreaming}
          disabled={!chatSession}
        />
      </div>
    </div>
  );
}