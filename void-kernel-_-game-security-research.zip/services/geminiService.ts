import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";
import { Message, Role } from '../types';

let client: GoogleGenAI | null = null;

// Initialize the client strictly with the env variable as requested
const getClient = (): GoogleGenAI => {
  if (!client) {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      console.error("API_KEY is missing from environment variables.");
      throw new Error("API Key missing");
    }
    client = new GoogleGenAI({ apiKey });
  }
  return client;
};

export const createChatSession = (modelName: string, systemInstruction: string) => {
  const ai = getClient();
  return ai.chats.create({
    model: modelName,
    config: {
      systemInstruction,
      temperature: 0.7, // Balanced for creativity and accuracy
    },
  });
};

export const sendMessageToChat = async (
  chat: Chat, 
  message: string
): Promise<AsyncGenerator<string, void, unknown>> => {
  try {
    const result = await chat.sendMessageStream({ message });
    
    // Return a generator to yield text chunks
    async function* streamGenerator() {
      for await (const chunk of result) {
        const c = chunk as GenerateContentResponse;
        if (c.text) {
          yield c.text;
        }
      }
    }
    return streamGenerator();

  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};