import React, { useRef, useEffect, useState } from 'react';
import { Message, Role } from '../types';
import { Bot, User, AlertTriangle, Copy, Check, Terminal, Code, Cpu, Minus, Square, X } from 'lucide-react';

interface ChatAreaProps {
  messages: Message[];
  isStreaming: boolean;
  currentTutorName: string;
}

export const ChatArea: React.FC<ChatAreaProps> = ({ messages, isStreaming }) => {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isStreaming]);

  return (
    <div className="flex-1 overflow-y-auto p-3 sm:p-4 md:p-10 space-y-8 md:space-y-12 scroll-smooth bg-void-900 perspective-1000 relative">
      {/* Background Ambience */}
      <div className="fixed inset-0 pointer-events-none bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-void-800 via-void-900 to-black opacity-50 z-0"></div>

      {messages.length === 0 && (
        <div className="h-full flex flex-col items-center justify-center select-none animate-in fade-in zoom-in duration-1000 z-10 relative px-4 text-center">
          <div className="relative group">
            <div className="absolute inset-0 bg-crimson-500/10 blur-3xl rounded-full group-hover:bg-crimson-500/20 transition-all duration-1000"></div>
            <Terminal size={60} className="relative mb-6 md:mb-8 text-goth-muted group-hover:text-crimson-800 transition-colors duration-500 sm:w-20 sm:h-20" strokeWidth={1} />
          </div>
          <p className="text-lg md:text-xl font-goth tracking-[0.3em] md:tracking-[0.4em] text-gray-400 uppercase drop-shadow-lg">System Ready</p>
          <div className="h-[1px] w-16 md:w-24 bg-crimson-900 my-4"></div>
          <p className="text-[10px] font-mono text-crimson-700/60 uppercase tracking-widest">Awaiting Input Stream</p>
        </div>
      )}

      <div className="relative z-10 space-y-6 md:space-y-10 pb-4">
        {messages.map((msg, index) => (
          <MessageItem key={msg.id} message={msg} isLast={index === messages.length - 1} />
        ))}
      </div>
      
      <div ref={bottomRef} className="h-4" />
    </div>
  );
};

const parseContent = (text: string) => {
  const parts = [];
  const regex = /```(\w+)?\n([\s\S]*?)```/g;
  let lastIndex = 0;
  let match;

  while ((match = regex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      parts.push({ type: 'text', content: text.slice(lastIndex, match.index) });
    }
    parts.push({ type: 'code', language: match[1] || 'plaintext', content: match[2] });
    lastIndex = regex.lastIndex;
  }
  if (lastIndex < text.length) {
    parts.push({ type: 'text', content: text.slice(lastIndex) });
  }
  return parts;
};

const MessageItem: React.FC<{ message: Message; isLast: boolean }> = ({ message, isLast }) => {
  const isUser = message.role === Role.USER;
  const contentParts = parseContent(message.text);

  return (
    <div className={`flex w-full ${isUser ? 'justify-end' : 'justify-start'} group perspective-1000`}>
      <div className={`
        flex gap-3 md:gap-6 max-w-full sm:max-w-[90%] md:max-w-[85%] lg:max-w-[80%]
        ${isUser ? 'flex-row-reverse' : 'flex-row'}
      `}>
        
        {/* Avatar */}
        <div className="flex-shrink-0 flex flex-col items-center gap-2 pt-1 hidden sm:flex">
          <div className={`
            w-8 h-8 flex items-center justify-center border backdrop-blur-md shadow-lg transition-transform duration-300 group-hover:scale-110
            ${isUser 
              ? 'bg-void-800 border-goth-border text-goth-muted rounded-md rotate-3' 
              : 'bg-void-950 border-crimson-900/40 text-crimson-500 shadow-neon rounded-md -rotate-3'
            }
          `}>
            {isUser ? <User size={14} /> : <Bot size={14} />}
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 space-y-4 md:space-y-6 min-w-0">
          
          {/* Header Info */}
          <div className={`flex items-center gap-2 md:gap-3 text-[9px] font-mono tracking-widest uppercase opacity-50 ${isUser ? 'justify-end' : 'justify-start'}`}>
            <span className={isUser ? 'text-goth-muted' : 'text-crimson-500 font-bold'}>
              {isUser ? 'OP_USER' : 'VOID_KERNEL'}
            </span>
            <span className="text-void-700">::</span>
            <span>{new Date(message.timestamp).toLocaleTimeString([], { hour12: false })}</span>
          </div>

          {contentParts.map((part, idx) => (
            part.type === 'code' ? (
              <CodeCanvas key={idx} language={part.language} code={part.content} />
            ) : (
              <div key={idx} className={`
                relative p-4 md:p-6 border backdrop-blur-xl shadow-xl transition-all duration-300
                ${isUser 
                  ? 'bg-void-800/60 border-goth-border/50 text-gray-300 rounded-2xl rounded-tr-none' 
                  : 'bg-void-950/60 border-crimson-900/20 text-gray-200 rounded-2xl rounded-tl-none hover:border-crimson-900/40'
                }
                ${message.isError ? 'border-crimson-500/50 bg-crimson-900/10' : ''}
              `}>
                <div className="font-mono text-xs sm:text-sm leading-6 sm:leading-7 whitespace-pre-wrap tracking-tight break-words">
                  {message.isError && (
                    <div className="flex items-center gap-2 text-crimson-500 mb-4 font-bold uppercase tracking-wider text-xs border-b border-crimson-900/30 pb-2">
                      <AlertTriangle size={14} />
                      <span>Runtime Exception</span>
                    </div>
                  )}
                  {part.content}
                </div>
              </div>
            )
          ))}

          {!isUser && isLast && message.text.length === 0 && (
             <div className="flex items-center gap-2 text-crimson-500 font-mono text-xs animate-pulse pl-1">
               <Cpu size={14} />
               <span>GENERATING_OUTPUT...</span>
             </div>
          )}

        </div>
      </div>
    </div>
  );
};

const CodeCanvas: React.FC<{ language: string; code: string }> = ({ language, code }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="relative group my-4 md:my-8 transform transition-transform duration-300 hover:scale-[1.01] hover:z-20 w-full max-w-full">
      
      {/* 3D Floating Window Container */}
      <div className="relative overflow-hidden bg-[#080808] border border-goth-border/80 shadow-[0_10px_40px_-10px_rgba(0,0,0,0.8)] rounded-lg">
        
        {/* Window Title Bar */}
        <div className="flex items-center justify-between px-3 py-2 md:px-4 md:py-2.5 bg-[#111] border-b border-goth-border">
          {/* Traffic Lights */}
          <div className="flex items-center gap-1.5 md:gap-2 group/lights">
            <div className="w-2.5 h-2.5 md:w-3 md:h-3 rounded-full bg-red-900/50 border border-red-800 group-hover/lights:bg-red-500 transition-colors flex items-center justify-center">
               <X size={6} className="opacity-0 group-hover/lights:opacity-100 text-black" />
            </div>
            <div className="w-2.5 h-2.5 md:w-3 md:h-3 rounded-full bg-yellow-900/50 border border-yellow-800 group-hover/lights:bg-yellow-500 transition-colors flex items-center justify-center">
              <Minus size={6} className="opacity-0 group-hover/lights:opacity-100 text-black" />
            </div>
            <div className="w-2.5 h-2.5 md:w-3 md:h-3 rounded-full bg-green-900/50 border border-green-800 group-hover/lights:bg-green-500 transition-colors flex items-center justify-center">
              <Square size={4} className="opacity-0 group-hover/lights:opacity-100 text-black" />
            </div>
          </div>
          
          {/* File Label */}
          <div className="flex items-center gap-2 text-[9px] md:text-[10px] font-mono text-goth-muted absolute left-1/2 transform -translate-x-1/2 opacity-70">
            <Code size={10} className="hidden sm:block" />
            <span className="uppercase tracking-wider truncate max-w-[100px]">{language || 'TEXT'}</span>
          </div>
          
          {/* Copy Button */}
          <button 
            onClick={handleCopy}
            className="flex items-center gap-1.5 text-[9px] md:text-[10px] font-mono uppercase text-goth-muted hover:text-white transition-colors bg-void-900 px-2 py-1 rounded border border-void-700 hover:border-goth-border"
          >
            {copied ? <Check size={10} className="text-emerald-500" /> : <Copy size={10} />}
            <span className="hidden sm:inline">{copied ? 'COPIED' : 'COPY'}</span>
          </button>
        </div>

        {/* Editor Area */}
        <div className="relative overflow-x-auto p-3 md:p-5 bg-[#050505] scrollbar-thin scrollbar-thumb-void-700">
           {/* Grid Pattern */}
           <div className="absolute inset-0 bg-grid-3d opacity-[0.05] pointer-events-none"></div>
           
           <pre className="font-mono text-[10px] sm:text-xs md:text-sm leading-5 md:leading-6 text-gray-300 min-w-max">
             <code>
               {code.split('\n').map((line, i) => (
                 <div key={i} className="table-row group/line hover:bg-white/[0.02] transition-colors">
                   <span className="table-cell text-right pr-4 md:pr-6 text-goth-muted select-none w-8 md:w-10 text-[9px] md:text-[10px] opacity-30 group-hover/line:opacity-70 group-hover/line:text-white transition-all border-r border-void-800">{i + 1}</span>
                   <span className="table-cell pl-3 md:pl-4 whitespace-pre">{line || ' '}</span>
                 </div>
               ))}
             </code>
           </pre>
        </div>

        {/* Status Bar */}
        <div className="bg-[#0a0a0a] border-t border-void-800 px-3 py-1 flex justify-end">
           <span className="text-[8px] md:text-[9px] font-mono text-void-700 uppercase">UTF-8 • UNIX • Ln {code.split('\n').length}</span>
        </div>

        {/* Neon Glow Line */}
        <div className="absolute bottom-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-crimson-900/50 to-transparent"></div>
      </div>

      {/* Back Glow */}
      <div className="absolute -inset-2 bg-crimson-900/5 blur-2xl -z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
    </div>
  );
};