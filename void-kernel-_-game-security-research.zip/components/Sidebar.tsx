import React from 'react';
import { TutorProfile } from '../types';
import { Activity, Lock, Server, ShieldCheck, Terminal, Cpu } from 'lucide-react';

interface SidebarProps {
  currentTutor: TutorProfile;
  isOpen: boolean;
  onClose: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose }) => {
  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/80 z-20 md:hidden backdrop-blur-sm"
          onClick={onClose}
        />
      )}

      {/* Sidebar Panel */}
      <div className={`
        fixed md:relative z-30 flex flex-col h-full w-72 bg-void-800 border-r border-goth-border
        transition-transform duration-300 ease-in-out font-mono
        ${isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
      `}>
        {/* Branding */}
        <div className="p-8 border-b border-goth-border">
          <h1 className="font-goth text-2xl text-white tracking-widest text-center">
            VOID <span className="text-crimson-700">KERNEL</span>
          </h1>
          <div className="mt-2 flex justify-center">
            <span className="text-[10px] text-crimson-500 border border-crimson-900/30 bg-crimson-900/10 px-2 py-0.5">
              UNRESTRICTED
            </span>
          </div>
        </div>

        {/* Status Modules */}
        <div className="flex-1 p-6 space-y-8 overflow-y-auto">
          
          {/* Module 1: System */}
          <div className="space-y-3">
            <h2 className="text-xs text-goth-muted uppercase tracking-[0.2em] border-b border-goth-border pb-1">System Status</h2>
            <div className="space-y-2">
              <StatusRow icon={Activity} label="Neural Engine" value="ONLINE" active />
              <StatusRow icon={Server} label="Latency" value="12ms" />
              <StatusRow icon={Cpu} label="Compute" value="RESERVED" />
            </div>
          </div>

          {/* Module 2: Security */}
          <div className="space-y-3">
            <h2 className="text-xs text-goth-muted uppercase tracking-[0.2em] border-b border-goth-border pb-1">Security Protocol</h2>
            <div className="space-y-2">
              <StatusRow icon={Lock} label="Encryption" value="AES-256" active />
              <StatusRow icon={ShieldCheck} label="Trace" value="DISABLED" active color="text-crimson-500" />
            </div>
          </div>

          {/* Decorative Terminal Output */}
          <div className="mt-8 p-3 bg-black border border-goth-border text-[10px] text-goth-muted font-mono leading-relaxed opacity-70">
            <p>> INIT_SEQ_COMPLETE</p>
            <p>> LOADING_MODULE_0X44</p>
            <p>> BYPASSING_FILTERS...</p>
            <p className="text-crimson-500">> ACCESS_GRANTED</p>
            <span className="animate-pulse">_</span>
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-goth-border bg-void-900">
           <div className="flex items-center gap-2 text-goth-muted text-xs">
             <div className="w-2 h-2 bg-crimson-700 rounded-full animate-pulse"></div>
             <span>SECURE CONNECTION</span>
           </div>
        </div>
      </div>
    </>
  );
};

const StatusRow: React.FC<{ icon: any, label: string, value: string, active?: boolean, color?: string }> = ({ icon: Icon, label, value, active, color }) => (
  <div className="flex items-center justify-between group">
    <div className="flex items-center gap-3 text-goth-muted group-hover:text-gray-300 transition-colors">
      <Icon size={14} />
      <span className="text-xs">{label}</span>
    </div>
    <span className={`text-xs font-bold ${color || (active ? 'text-emerald-500' : 'text-gray-600')}`}>
      {value}
    </span>
  </div>
);
