import React from 'react';
import { Terminal, Shield, Cpu, ChevronRight, Code2, Activity, Zap } from 'lucide-react';

interface LandingPageProps {
  onEnter: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onEnter }) => {
  return (
    <div className="relative w-full min-h-screen overflow-y-auto overflow-x-hidden flex flex-col bg-void-900 font-sans selection:bg-crimson-900 selection:text-white scrollbar-thin scrollbar-track-black scrollbar-thumb-crimson-900">
      
      {/* Dynamic Background */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-br from-black via-void-900 to-void-950"></div>
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgb3BhY2l0eT0iMC4wMyI+CjxwYXRoIGQ9Ik0wIDBoNDB2NDBIMHoiIGZpbGw9Im5vbmUiLz4KPHBhdGggZD0iTTAgNDBMMTQgMGgyTDE2IDQwIiBzdHJva2U9IiNmZmYiIHN0cm9rZS13aWR0aD0iMSIvPgo8L3N2Zz4=')] opacity-10"></div>
        {/* Animated Glow Orbs */}
        <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-crimson-900/10 rounded-full blur-[100px] animate-pulse-slow"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[600px] h-[600px] bg-void-800/50 rounded-full blur-[120px]"></div>
      </div>

      <div className="z-10 w-full max-w-7xl mx-auto px-6 lg:px-8 py-12 lg:py-20 flex-1 flex flex-col">
        
        {/* Navigation / Header */}
        <div className="w-full flex justify-between items-center mb-16 lg:mb-24 border-b border-white/5 pb-4">
           <div className="flex items-center gap-2">
             <Terminal size={20} className="text-crimson-600" />
             <span className="font-goth font-bold text-gray-200 tracking-[0.2em] text-lg">VOID KERNEL</span>
           </div>
           <div className="flex items-center gap-2 text-[10px] font-mono text-goth-muted uppercase tracking-widest">
             <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_10px_#10b981]"></div>
             <span>System: Stable</span>
           </div>
        </div>

        {/* Hero Section */}
        <div className="flex flex-col-reverse lg:flex-row items-center justify-between gap-16 lg:gap-8">
          
          {/* Left Column: Text Content */}
          <div className="flex-1 text-center lg:text-left space-y-8 z-20 max-w-2xl">
            <div className="inline-block">
              <div className="inline-flex items-center gap-3 text-crimson-400 border border-crimson-900/30 bg-crimson-950/20 px-4 py-1.5 rounded-full text-[10px] sm:text-xs font-mono tracking-widest uppercase mb-4">
                <Activity size={12} />
                <span>Recursive Analysis Protocol</span>
              </div>
            </div>

            <h1 className="text-5xl sm:text-7xl lg:text-8xl font-goth tracking-tighter text-white leading-[0.9] drop-shadow-xl">
              HACK THE <br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-crimson-600 via-crimson-500 to-white animate-pulse">MATRIX</span>
            </h1>

            <p className="text-goth-muted font-mono text-sm sm:text-base leading-relaxed max-w-xl mx-auto lg:mx-0 border-l-2 border-crimson-800 pl-6 text-justify">
              Advanced automated architecture for game security, low-level memory manipulation, and kernel driver analysis. Developed by <span className="text-gray-300 font-bold border-b border-crimson-700/50 hover:text-crimson-500 transition-colors cursor-help" title="Class 10 Student, Barguna BD">Abdullah Mun Eshan</span>.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start pt-4">
              <button 
                onClick={onEnter}
                className="group relative px-8 py-4 bg-crimson-700 hover:bg-crimson-600 text-white font-mono uppercase tracking-widest text-xs font-bold transition-all duration-300 clip-path-polygon shadow-[0_0_20px_rgba(220,38,38,0.3)] hover:shadow-[0_0_40px_rgba(220,38,38,0.6)]"
              >
                <div className="flex items-center gap-3">
                  <span>Initialize Kernel</span>
                  <ChevronRight size={14} className="group-hover:translate-x-1 transition-transform" />
                </div>
              </button>
              
              <button className="px-8 py-4 border border-white/10 hover:border-white/30 text-goth-muted hover:text-white font-mono uppercase tracking-widest text-xs font-bold transition-all duration-300 bg-black/20 backdrop-blur-sm">
                 Documentation
              </button>
            </div>
          </div>

          {/* Right Column: CSS Void Core Animation */}
          <div className="flex-1 flex items-center justify-center py-10 lg:py-0 w-full">
             <div className="relative w-72 h-72 sm:w-96 sm:h-96">
                {/* The Void Core - Pure CSS Animation */}
                <div className="absolute inset-0 flex items-center justify-center transform-style-3d perspective-1000">
                  
                  {/* Outer Ring */}
                  <div className="absolute w-full h-full rounded-full border border-crimson-900/20 border-t-crimson-500 animate-[spin_10s_linear_infinite] shadow-[0_0_50px_rgba(220,38,38,0.1)]"></div>
                  
                  {/* Middle Ring */}
                  <div className="absolute w-[80%] h-[80%] rounded-full border border-void-700/30 border-b-gray-400 animate-[spin_15s_linear_infinite_reverse]"></div>
                  
                  {/* Inner Dashed Ring */}
                  <div className="absolute w-[60%] h-[60%] rounded-full border-2 border-dashed border-crimson-900/40 animate-[spin_20s_linear_infinite]"></div>
                  
                  {/* Core Cube Effect (2D representation of 3D) */}
                  <div className="relative w-24 h-24 bg-black border border-crimson-500/50 rotate-45 animate-float shadow-[0_0_50px_rgba(220,38,38,0.4)]">
                     <div className="absolute inset-2 border border-white/20"></div>
                     <div className="absolute inset-0 bg-crimson-900/20 backdrop-blur-sm"></div>
                  </div>

                  {/* Scanning Line */}
                  <div className="absolute w-full h-1 bg-gradient-to-r from-transparent via-crimson-500 to-transparent top-1/2 -translate-y-1/2 opacity-20 animate-pulse"></div>

                </div>
                
                {/* Glow Backdrop */}
                <div className="absolute inset-0 bg-crimson-600/5 blur-3xl rounded-full -z-10"></div>
             </div>
          </div>

        </div>

        {/* Feature Grid */}
        <div className="mt-24 grid grid-cols-1 md:grid-cols-3 gap-6">
          <GridCard 
            icon={Cpu} 
            title="Memory Analysis" 
            desc="Pointer scanning, offset dumping, and heap inspection logic." 
          />
          <GridCard 
            icon={Code2} 
            title="Code Injection" 
            desc="LoadLibrary, Manual Mapping, and thread hijacking techniques." 
          />
          <GridCard 
            icon={Shield} 
            title="Kernel Driver" 
            desc="Ring 0 communication and hypervisor evasion strategies." 
          />
        </div>

        {/* Footer */}
        <div className="mt-20 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] text-goth-muted font-mono uppercase tracking-widest opacity-60">
           <div className="flex items-center gap-2">
             <span>Build 9921.4</span>
             <span className="w-1 h-1 bg-gray-500 rounded-full"></span>
             <span>Region: BD/BARGUNA</span>
           </div>
           <div>
             Designed by Abdullah Mun Eshan
           </div>
        </div>

      </div>
    </div>
  );
};

const GridCard: React.FC<{ icon: any, title: string, desc: string }> = ({ icon: Icon, title, desc }) => (
  <div className="p-6 bg-white/[0.02] border border-white/5 hover:border-crimson-900/50 hover:bg-white/[0.04] transition-all duration-300 group">
    <div className="w-10 h-10 bg-black border border-white/10 flex items-center justify-center mb-4 group-hover:border-crimson-700/50 transition-colors">
      <Icon size={20} className="text-gray-400 group-hover:text-crimson-500 transition-colors" />
    </div>
    <h3 className="font-goth text-gray-200 text-lg mb-2 group-hover:text-white">{title}</h3>
    <p className="font-mono text-xs text-goth-muted leading-relaxed group-hover:text-gray-400">
      {desc}
    </p>
  </div>
);
