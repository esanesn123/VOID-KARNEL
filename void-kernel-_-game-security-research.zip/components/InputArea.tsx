import React, { useState, useRef, useEffect } from 'react';
import { ChevronRight, Square, Command, Wifi } from 'lucide-react';

interface InputAreaProps {
  onSend: (text: string) => void;
  onStop: () => void;
  isStreaming: boolean;
  disabled: boolean;
}

export const InputArea: React.FC<InputAreaProps> = ({ onSend, onStop, isStreaming, disabled }) => {
  const [input, setInput] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || disabled) return;
    onSend(input);
    setInput('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 150)}px`;
    }
  }, [input]);

  return (
    <div className="p-3 md:p-6 bg-void-900 border-t border-goth-border/50 relative z-20 shadow-[0_-5px_20px_rgba(0,0,0,0.5)]">
      <div className="max-w-4xl mx-auto space-y-2">
        
        {/* Input Container */}
        <div className={`
            relative flex items-end gap-2 md:gap-3 p-2 md:p-4 
            bg-[#050505] border border-goth-border 
            focus-within:border-crimson-900 focus-within:ring-1 focus-within:ring-crimson-900/20 focus-within:shadow-[0_0_15px_rgba(185,28,28,0.1)]
            transition-all duration-300 rounded-lg
          `}>
          
          <div className="pb-2 text-crimson-600 animate-pulse hidden md:block">
            <span className="font-mono text-lg font-bold">root@void:~#</span>
          </div>
          <div className="pb-2 text-crimson-600 md:hidden pl-1">
            <ChevronRight size={16} />
          </div>

          <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={isStreaming ? "PROCESSING_STREAM..." : "ENTER_COMMAND..."}
            className="flex-1 max-h-[120px] md:max-h-[150px] min-h-[24px] bg-transparent text-gray-200 placeholder-void-700 text-sm font-mono p-1 resize-none focus:outline-none scrollbar-thin scrollbar-thumb-void-700"
            disabled={disabled || isStreaming}
            rows={1}
            autoFocus
          />

          <div className="pb-1 pr-1">
            {isStreaming ? (
              <button
                onClick={onStop}
                className="text-crimson-500 hover:text-crimson-400 transition-colors p-2 rounded-full hover:bg-crimson-900/10 active:scale-95"
              >
                <Square size={16} fill="currentColor" />
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                disabled={!input.trim() || disabled}
                className={`
                  p-2 rounded-md transition-all duration-200 flex items-center gap-2 active:scale-95
                  ${!input.trim() || disabled 
                    ? 'text-void-700 cursor-not-allowed' 
                    : 'bg-crimson-900/10 text-crimson-500 hover:bg-crimson-900/20 hover:text-white hover:shadow-neon'
                  }
                `}
              >
                <span className="text-[10px] font-mono font-bold uppercase tracking-widest hidden md:inline">Execute</span>
                <Command size={16} />
              </button>
            )}
          </div>
        </div>

        {/* Footer Info Line */}
        <div className="flex justify-between px-2 opacity-50 hidden sm:flex">
          <div className="flex items-center gap-3 text-[9px] text-goth-muted font-mono tracking-widest uppercase">
             <span className="flex items-center gap-1"><Wifi size={10} /> LINK_ESTABLISHED</span>
             <span>|</span>
             <span>LATENCY: 12ms</span>
          </div>
          <div className="text-[9px] text-goth-muted font-mono">
            <span>SECURE CHANNEL (TLS 1.3)</span>
          </div>
        </div>
      </div>
    </div>
  );
};