export enum Role {
  USER = 'user',
  MODEL = 'model'
}

export interface Message {
  id: string;
  role: Role;
  text: string;
  timestamp: number;
  isError?: boolean;
}

export interface TutorProfile {
  id: string;
  name: string;
  description: string;
  icon: string;
  systemInstruction: string;
  model: string;
  themeColor: string;
}

export interface ChatSession {
  id: string;
  tutorId: string;
  messages: Message[];
  createdAt: number;
}